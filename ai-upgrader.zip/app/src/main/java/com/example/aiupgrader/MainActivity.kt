package com.example.aiupgrader

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private val filePath = "app/src/main/java/com/example/aiupgrader/MainActivity.kt"
    private val branch = "ai-update"

    private lateinit var geminiKey: EditText
    private lateinit var model: EditText
    private lateinit var ghToken: EditText
    private lateinit var repo: EditText
    private lateinit var request: EditText
    private lateinit var output: TextView
    private var generatedCode: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        fun field(hint: String, key: String, secret: Boolean = false, def: String = ""): EditText {
            val e = EditText(this)
            e.hint = hint
            e.setText(prefs.getString(key, def))
            if (secret) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            root.addView(e)
            return e
        }
        fun button(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { action() }
            root.addView(b)
        }

        geminiKey = field("Gemini API key", "gk", true)
        model = field("Gemini model", "gm", false, "gemini-2.5-flash")
        ghToken = field("GitHub token", "gt", true)
        repo = field("GitHub repo (owner/name)", "gr")
        request = field("What should the app change/add?", "rq")
        request.minLines = 3

        output = TextView(this).apply { setTextIsSelectable(true); text = "Ready." }

        button("1. Ask Gemini to upgrade the app") { askGemini() }
        button("2. Push result to '$branch' branch (builds APK)") { pushCode() }
        button("3. Check latest release / download APK") { checkRelease() }
        root.addView(output)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun savePrefs() {
        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
            .putString("gk", geminiKey.text.toString())
            .putString("gm", model.text.toString())
            .putString("gt", ghToken.text.toString())
            .putString("gr", repo.text.toString())
            .putString("rq", request.text.toString())
            .apply()
    }

    private fun log(msg: String) = runOnUiThread { output.text = msg }

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 30000
        c.readTimeout = 120000
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, text)
    }

    private fun ghHeaders() = mapOf(
        "Authorization" to "Bearer ${ghToken.text.toString().trim()}",
        "Accept" to "application/vnd.github+json",
        "Content-Type" to "application/json"
    )

    private fun api(p: String) = "https://api.github.com/repos/${repo.text.toString().trim()}$p"

    private fun askGemini() {
        savePrefs()
        log("Reading current code from GitHub...")
        thread {
            try {
                val (c1, r1) = http("GET", api("/contents/$filePath?ref=main"), ghHeaders(), null)
                if (c1 != 200) { log("GitHub error $c1:\n$r1"); return@thread }
                val current = String(Base64.decode(JSONObject(r1).getString("content"), Base64.DEFAULT))

                log("Asking Gemini...")
                val prompt = "You are improving an Android app written in Kotlin (plain android.app.Activity, " +
                    "no external libraries, minSdk 24). Below is the full current MainActivity.kt. " +
                    "Apply this change: ${request.text}\n\n" +
                    "Rules: keep package com.example.aiupgrader, keep the three existing buttons working, " +
                    "use only Android SDK classes. Return ONLY the complete new file, no explanations, no markdown.\n\n" +
                    "CURRENT FILE:\n$current"
                val body = JSONObject().put("contents", JSONArray().put(
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                )).toString()
                val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
                    "${model.text.toString().trim()}:generateContent"
                val (c2, r2) = http("POST", url,
                    mapOf("Content-Type" to "application/json",
                          "x-goog-api-key" to geminiKey.text.toString().trim()), body)
                if (c2 != 200) { log("Gemini error $c2:\n$r2"); return@thread }
                var text = JSONObject(r2).getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                text = text.trim().removePrefix("```kotlin").removePrefix("```").removeSuffix("```").trim()
                if (!text.contains("package com.example.aiupgrader")) {
                    log("Gemini returned something unexpected:\n$text"); return@thread
                }
                generatedCode = text
                log("New code generated (${text.length} chars). Review it, then press button 2.\n\n$text")
            } catch (e: Exception) { log("Error: $e") }
        }
    }

    private fun pushCode() {
        if (generatedCode.isEmpty()) { log("Generate code first (button 1)."); return }
        savePrefs()
        log("Pushing to branch '$branch'...")
        thread {
            try {
                val (c0, r0) = http("GET", api("/git/ref/heads/main"), ghHeaders(), null)
                if (c0 != 200) { log("GitHub error $c0:\n$r0"); return@thread }
                val sha = JSONObject(r0).getJSONObject("object").getString("sha")
                // Create branch; 422 means it already exists, which is fine.
                http("POST", api("/git/refs"), ghHeaders(),
                    JSONObject().put("ref", "refs/heads/$branch").put("sha", sha).toString())

                val (c1, r1) = http("GET", api("/contents/$filePath?ref=$branch"), ghHeaders(), null)
                val body = JSONObject()
                    .put("message", "AI upgrade: ${request.text}")
                    .put("branch", branch)
                    .put("content", Base64.encodeToString(generatedCode.toByteArray(), Base64.NO_WRAP))
                if (c1 == 200) body.put("sha", JSONObject(r1).getString("sha"))
                val (c2, r2) = http("PUT", api("/contents/$filePath"), ghHeaders(), body.toString())
                if (c2 in 200..201) {
                    log("Pushed! GitHub Actions is now testing and building.\n" +
                        "Open your repo > Actions tab. If it is green, download the APK artifact.\n" +
                        "To release it, merge branch '$branch' into main.")
                } else log("Push failed $c2:\n$r2")
            } catch (e: Exception) { log("Error: $e") }
        }
    }

    private fun checkRelease() {
        savePrefs()
        log("Checking latest release...")
        thread {
            try {
                val (c, r) = http("GET", api("/releases/latest"), ghHeaders(), null)
                if (c != 200) { log("No release found ($c):\n$r"); return@thread }
                val j = JSONObject(r)
                val assets = j.getJSONArray("assets")
                val apkUrl = if (assets.length() > 0) assets.getJSONObject(0).getString("browser_download_url") else ""
                log("Latest: ${j.getString("tag_name")}\n$apkUrl\n\nOpening download...")
                if (apkUrl.isNotEmpty()) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(apkUrl)))
                }
            } catch (e: Exception) { log("Error: $e") }
        }
    }
}
