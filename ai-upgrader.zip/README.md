# AI Upgrader (Android)

1. Upload all these files to a new GitHub repo (branch: main).
2. Repo > Settings > Actions > General > Workflow permissions > "Read and write".
3. Actions tab > "Build APK" > download artifact `app-apk` (or Releases page).
4. Install APK. In the app enter: Gemini key, GitHub token, repo (owner/name).
5. Create GitHub token: Settings > Developer settings > Fine-grained tokens >
   select your repo > Repository permissions: Contents = Read and write.
6. Use the app: write request > button 1 > review > button 2 > check Actions > merge to main.
